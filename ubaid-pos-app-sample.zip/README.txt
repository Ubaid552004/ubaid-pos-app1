Ubaid POS App – Sample Data Package

This includes sample products, restaurant menu, and clinic patients
to help you test the app right after installation.

📂 lib/sampleData.json contains the pre-filled data.
